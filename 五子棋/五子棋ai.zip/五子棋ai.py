# -*- coding: utf-8 -*-
"""
Created on Tue Nov  3 19:26:42 2020

@author: 严天宇
"""

import pygame as pg
from enum import IntEnum

class chessboard:
    def __init__(self):
        self.grid__length=26
        self.grid__count=20
        self.start__x=150
        self.start__y=50
        self.edge__length=self.grid__length/2
        self.piece='mine'
        self.winner=True
        self.gameover=False
        self.grid=[['empty' for i in range(self.grid__count)] for j in range(self.grid__count)]
            
        
    def handle__event(self,i):
        origin__x=self.start__x-self.edge__length
        origin__y=self.start__y-self.edge__length
        chessboard__length=(self.grid__count-1)*self.grid__length+2*self.edge__length
        mouse__pos=i.pos
        if(mouse__pos[0]>origin__x and mouse__pos[0]<origin__x+chessboard__length) and (mouse__pos[1]>origin__y and mouse__pos[1]<origin__y+chessboard__length):
            if not self.gameover:
                x=mouse__pos[0]-origin__x
                m=int(x/self.grid__length)
                y=mouse__pos[1]-origin__y
                n=int(y/self.grid__length)
                if self.set__piece(m,n):          
                    self.check__win(m,n)
                    
    
    def set__piece(self,m,n):
        if self.grid[m][n]=="empty":
            self.grid[m][n]=self.piece
            if self.piece=='mine':
                self.piece='opponent'
            else:
                self.piece='mine'
            return True          
        return False
    
    def check__win(self,m,n):
        assert type(m)==int
        w__count= self.getResult(m,n,0,1)
        s__count= self.getResult(m,n,0,-1)
        a__count= self.getResult(m,n,-1,0)
        d__count= self.getResult(m,n,1,0)
        q__count= self.getResult(m,n,-1,-1)
        e__count= self.getResult(m,n,1,-1)
        z__count= self.getResult(m,n,-1,1)
        c__count= self.getResult(m,n,1,1)
        if (w__count+s__count+1>=5) or(a__count+d__count+1>=5) or(q__count+c__count+1>=5) or (z__count+e__count+1>=5):
               self.winner=self.grid[m][n]
               self.gameover=True
               
    def getResult(self,m,n,dm,dn):
        piece=self.grid[m][n]
        result=0
        i=1
        while True:
            new__m=m+dm*i
            new__n=n+dn*i
            if new__m<=self.grid__count and new__n<=self.grid__count and new__m>=0 and new__n>=0:
                if self.grid[new__m][new__n]==piece :
                    result+=1
                else:
                    break
            else:
                break              
            i+=1
        return result
    
    def draw(self,screen):
        pg.draw.rect(screen,(180,150,80),[self.start__x-self.edge__length,self.start__y-self.edge__length,
                                           self.grid__length*(self.grid__count-1)+self.edge__length*2,self.grid__length*(self.grid__count-1)+self.edge__length*2],0)
        for i in range(self.grid__count):
            y=self.start__y+i*self.grid__length
            pg.draw.line(screen,(0,0,0),[self.start__x,y],[self.start__x+(self.grid__count-1)*self.grid__length,y],2)
        for j in range(self.grid__count):
            x=self.start__x+j*self.grid__length
            pg.draw.line(screen,(0,0,0),[x,self.start__y],[x,self.start__y+self.grid__length*(self.grid__count-1)],2)
        for i in range(self.grid__count):
            for j in range(self.grid__count):
                piece=self.grid[i][j]
                if piece!="empty":
                    if piece=='mine':
                        color=(0,0,0)
                    else:
                        color=(255,255,255)
                    x=self.start__x+self.grid__length*i
                    y=self.start__y+self.grid__length*j
                    pg.draw.circle(screen,color,[x,y],self.grid__length//2)
                
class chessgame:
    def __init__(self):
        pg.init()
        self.screen=pg.display.set_mode((800,600))
        pg.display.set_caption('五子棋')
        self.clock=pg.time.Clock()
        self.font=pg.font.Font(u"C:\Windows\Fonts\Arial.ttf",24)
        self.going=True
        self.chessboard=chessboard()
    
    def main(self):
        while self.going:
            AI=chessAI(self.chessboard.grid__count,self.chessboard.grid,self.chessboard.piece)
            (x,y)=AI.find_best_chess(self.chessboard.grid,self.chessboard.piece)
            self.chessboard.set__piece(x,y)
            self.chessboard.check__win(x,y)
            self.draw()
            if self.chessboard.gameover :
                break
            self.update()
            self.draw()
            if self.chessboard.gameover :
                break
            self.clock.tick(50)
        pg.quit()
    
    def update(self):
        while True:
            for i in pg.event.get():
                if i.type == pg.QUIT:
                    self.going= False
                elif i.type== pg.MOUSEBUTTONDOWN:
                    self.chessboard.handle__event(i)
                    return None
                
    def draw(self):
        self.screen.fill((0,255,120))
        self.screen.blit(self.font.render("FPS:{0:.2f}".format(self.clock.get_fps()),True,(0,0,0)),(10,10))
        self.chessboard.draw(self.screen)
        if self.chessboard.gameover:
            self.screen.blit(self.font.render("{0} wins".format('black' if self.chessboard.winner=='mine' else 'white'),True,(255,0,0)),(500,10))
        pg.display.update()

class CHESS_TYPE(IntEnum):
    NONE=0
    SLEEP_TWO=1
    LIVE_TWO=2
    SLEEP_THREE=3
    LIVE_THREE=4
    CHONG_FOUR=5
    LIVE_FOUR=6
    LIVE_FIVE=7

CHESS_TYPE_NUM=8

FIVE = CHESS_TYPE.LIVE_FIVE.value
FOUR=CHESS_TYPE.LIVE_FOUR.value
THREE=CHESS_TYPE.LIVE_THREE.value
TWO=CHESS_TYPE.LIVE_TWO.value
SFOUR=CHESS_TYPE.CHONG_FOUR.value
STHREE=CHESS_TYPE.SLEEP_THREE.value
STWO=CHESS_TYPE.SLEEP_TWO.value

class chessAI():
    def __init__(self,chess_len,board,turn):
        self.len=chess_len
        self.record=[[[0,0,0,0] for i in range(self.len)]for j in range(self.len)]#四个大方向的子数目
        self.count=[[0 for i in range(8)] for j in range(2)]#有多少模型
        self.board=board
        self.turn=turn
        
        
    def pos_score(x,y):                       #靠近中心更好
        return -(abs(x-7)+abs(y-7))
    
    def reset(self):                          #走一步之后重置
        for i in range(self.len):
            for j in range(self.len):
                for k in range(4):
                    self.record[i][j][k]=0
        for i in range(2):
            for j in range(8):
                self.count[i][j]=0
        self.save_count=0
    
    def isWin(self,board,turn):                #输赢
        return self.evaluate(board,turn,True)
                
    def move_pos(self,board):           #找空格       !
        moves=[]
        for i in range(self.len):
            for j in range(self.len):
                if board[i][j]=="empty":
                    score=-(abs(i-7)+abs(j-7))
                    moves.append((score,i,j))
        moves.sort(reverse=True)
        return moves
    
    def search(self,board,turn):            #从哪里开始先进行估值    !
        moves=self.move_pos(board)
        max_score=-1000000
        bestmove=()
        for score,x,y in moves:
            score=self.evaluate(board,turn)
            if score >max_score:
                max_score=score
                bestmove=(max_score,x,y)
        return bestmove                    #(tuple)
    
    def find_best_chess(self,board,turn):         #return 点
        a=self.search(board,turn)
        score,x,y=a[0],a[1],a[2]
        return (x,y)
    
    def get_score(self,mine_count,opponent_count):   #return (mscore,oscore)
        mscore,oscore = 0,0
        if mine_count[FIVE]>0 :
            return (10000,0)
        if opponent_count[FIVE]>0:
            return (0,10000)
        
        if mine_count[SFOUR] >=2 :
            mine_count[FOUR]+=1
        
        if opponent_count[FOUR]>0:
            return (0,9050)
        if opponent_count[SFOUR]>0:
            return (0,9040)
        
        if mine_count[FOUR] >0:
            return (9030,0)
        if mine_count[SFOUR] >0:
            return (9020,0)
        
        if opponent_count[THREE]>0 and mine_count[SFOUR]==0:
            return (0,9010)
        
        if mine_count[THREE]>1 and opponent_count[THREE]==0 and opponent_count[STHREE]==0 :
            return (9000,0)
        
        if mine_count[SFOUR] >0:
            mscore +=2000
        
        if mine_count[THREE]>1:
            mscore+=500
        elif mine_count[THREE]>0:
            mscore+=100
        
        if opponent_count[THREE] >1:
            oscore+=2000
        elif opponent_count[THREE] >0:
            oscore+=400
        
        if mine_count[STHREE]>0:
            mscore+=mine_count[STHREE]*10
        if opponent_count[STHREE]>0:
            oscore+=opponent_count[STHREE]*10
        
        if mine_count[TWO]>0:
            mscore+=mine_count[TWO]*4
        if opponent_count[TWO]>0:
            oscore+=opponent_count[TWO]*4
            
        if mine_count[STWO] > 0:
            mscore += mine_count[STWO] * 4
        if opponent_count[STWO] > 0:
            oscore += opponent_count[STWO] * 4
        
        return (mscore,oscore)
        
    def evaluate(self,board,turn,check_win=False):
        self.reset()
        if turn=='mine':      #ai下棋？？  PLAYER TURN
            mine=1
            opponent=2
        else:
            mine=2
            opponent=1
        for x in range(self.len):
            for y in range(self.len):
                if board[x][y]=='mine':
                    self.evaluate_point(board,x,y,mine,opponent)
                elif board[x][y]=='opponent' :
                    self.evaluate_point(board,x,y,opponent,mine)
        
        mine_count =self.count[mine-1]
        opponent_count=self.count[opponent-1]
        
        if check_win :
            return mine_count[FIVE]>0
        else:
            mscore,oscore=self.get_score(mine_count,opponent_count)
            return (mscore-oscore)
    
    def evaluate_point(self,board,x,y,mine,opponent):
        direction=[(1,0),(0,1),(1,1),(1,-1)]
        for i in range(4):
            if self.record[x][y][i]==0:
                self.analysis_line(board,x,y,i,direction[i],mine, opponent,self.count[mine-1])
            else:
                self.save_count+=1
    
    def get_line(self,board,x,y,direction,mine,opponent):
        line=[0 for i in range(9)]
        tem_x=x+(-5*direction[0])
        tem_y=y+(-5*direction[1])         #???
        for i in range(9):
            tem_x+=direction[0]
            tem_y+=direction[1]
            if (tem_x <0 or tem_x >=self.len) or (tem_y<0 or tem_y>=self.len):
                line[i]='opponent'
            else:
                line[i]=board[tem_x][tem_y]
        return line
        
    def analysis_line(self,board,x,y,dir_index,direction,mine,opponent,count):
        def set_record(self,x,y,left,right,dir_index,direction):
            tmp_x=x+(-5+left)*direction[0]
            tmp_y=y+(-5+left)*direction[1]
            for i in range(left,right):
                tmp_x+=direction[0]
                tmp_y+=direction[1]
                self.record[tmp_x][tmp_y][dir_index]=1
        
        left_idx,right_idx =4,4
        
        line=self.get_line(board,x,y,direction,mine,opponent)
        
        while right_idx<8 :
            if line[right_idx+1]!='mine':
                break
            right_idx+=1
        while left_idx >0:
            if line[left_idx-1]!='mine':
                break
            left_idx-=1
        
        left_range, right_range=left_idx,right_idx
        while right_range <8 :
            if line[right_range+1] == 'opponent':
                break
            right_range+=1
        while left_range >0 :
            if line[left_range+1] == 'opponent':
                break
            left_range-=1
        
        chess_range =right_range - left_range+1
        if chess_range <5 :
            set_record(self,x,y,left_range,right_range,dir_index,direction)
            return CHESS_TYPE.NONE
        
        set_record(self,x,y,left_idx,right_idx,dir_index,direction)
        
        m_range=right_idx-left_idx+1
        if m_range>=5 :
            count[FIVE]+=1
        if m_range==4 :
            left_empty=right_empty =False
            if line[left_idx-1]=='empty':
                left_empty=True
            if line[right_idx+1]=='empty':
                right_empty=True
            if left_empty and right_empty :
                count[FOUR]+=1
            elif left_empty or right_empty :
                count[SFOUR]+=1
        
        if m_range==3 :
            left_empty = right_empty =False
            left_four = right_four =False
            if line[left_idx-1]=='empty':
                if line[left_idx-2]=='mine' :
                    set_record(self,x,y,left_idx-2,left_idx-1,dir_index,direction)
                    count[SFOUR]+=1
                    left_four=True
                left_empty=True
            
            if line[right_idx+1]=='empty':
                if line[right_idx+2]=='mine':
                    set_record(self,x,y,right_idx+2,right_idx+1,dir_index,direction)
                    count[SFOUR]+=1
                    right_four=True
                right_empty=True
            
            if left_four or right_four:
                pass
            elif left_empty and right_empty:
                if chess_range>5:
                    count[THREE]+=1
                else:
                    count[STHREE]+=1
            elif left_empty or right_empty :
                count[STHREE]+=1
            
        if m_range==2 :
            left_empty=right_empty=False
            left_three=right_three=False
            if line[left_idx-1]=='empty' :
                if line[left_idx-2]=='mine':
                    set_record(self,x,y,left_idx-2,left_idx-1,dir_index,direction)
                    if line[left_idx-3]=='empty':
                        if line[right_idx+1]=='empty':
                            count[THREE]+=1
                        else:
                            count[STHREE]+=1
                        left_three = True
                    elif line[left_idx-3] == 'opponent': # PMXMMX
                        if line[right_idx+1] == 'empty':
                            count[STHREE] += 1
                            left_three = True
                left_empty=True
            
            if line[right_idx+1] == 'empty':
                if line[right_idx+2] == 'mine':
                    if line[right_idx+3] == 'mine':  
                        set_record(self, x, y, right_idx+1, right_idx+2, dir_index, dir)
                        count[SFOUR] += 1
                        right_three = True
                    elif line[right_idx+3] == 'empty':
                        if left_empty:  
                            count[THREE] += 1
                        else:  
                            count[STHREE] += 1
                        right_three = True
                    elif left_empty: 
                        count[STHREE] += 1
                        right_three = True
						
                right_empty = True
            
            if left_three or right_three:
                pass
            elif left_empty and right_empty:
                count[TWO] += 1
            elif left_empty or right_empty:
                count[STWO] += 1
            
        if m_range == 1:
            left_empty = right_empty = False
            if line[left_idx-1] == 'empty':
                if line[left_idx-2] == 'mine':
                    if line[left_idx-3] == 'empty':
                        if line[right_idx+1] == 'opponent':
                            count[STWO] += 1
                left_empty=True
				
            if line[right_idx+1] == 'empty':
                if line[right_idx+2] == 'mine':
                    if line[right_idx+3] == 'empty':
                        if left_empty:
                            count[TWO] += 1
                        else: 
                            count[STWO] += 1
                elif line[right_idx+2] == 'empty':
                    if line[4+3] == 'mine' and line[4+4] == 'empty': # ?
                        count[TWO] += 1
        return CHESS_TYPE.NONE 
                              
if __name__=='__main__':
    game=chessgame()
    game.main()