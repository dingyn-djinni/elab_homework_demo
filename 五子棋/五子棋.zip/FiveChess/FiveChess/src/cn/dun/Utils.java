package cn.dun;

/**
 *返回信息流
 */
public class Utils {
    static String buildMessage(String head, String body) {
        return head + ':' + body;
    }
}
